# Standard Operating Procedure (SOP)
### Arth Kavach Global IMF Limited — CRM Portal
**Roles covered:** 1 Admin, 4 Agents

---

## 1. Purpose

This SOP defines how the Admin and Agents at Arth Kavach Global IMF Limited
should use the CRM portal day-to-day, so that leads are followed up on
time, tasks don't go overdue, and client/opportunity records stay accurate
and consistent across the team.

---

## 2. Roles & Responsibilities

### 2.1 Admin
- Owns the CRM: adds/removes agent accounts, resets forgotten passwords.
- Receives new leads (from calls, website, referrals, walk-ins) and
  **assigns each one to an agent** within the same working day.
- Reviews the Dashboard each morning for Overdue tasks/opportunities across
  the whole team and follows up with the relevant agent.
- Reassigns leads/tasks if an agent is on leave or overloaded.
- Has final authority to delete duplicate or incorrect records.
- Runs a weekly review (see Section 6).

### 2.2 Agents (4 seats)
- Log in each morning and check **Dashboard → Overdue / Due Today**.
- Work only the Leads/Clients/Tasks/Opportunities assigned to them.
- Update a Lead's status the same day contact is attempted — never leave a
  lead sitting at "New" after it has been called.
- Create a Task for any required follow-up with a realistic due date,
  rather than relying on memory.
- Keep Notes fields factual and professional — they may be read by the
  Admin or a teammate covering for you.
- Change their password immediately after receiving a new account or a
  password reset, and never share their login with anyone else.

---

## 3. Daily Workflow (Agents)

1. **Log in** at the CRM URL provided by your Admin.
2. Check the **Dashboard**: note any red "Overdue" counts first.
3. Open **Tasks**, sorted by due date; action anything due today or overdue.
4. Open **Leads** assigned to you:
   - Contact new leads (call/message per your usual script).
   - Update **Status**: `New` → `Contacted` → `Qualified` → `Converted`
     (or `Lost` if the lead does not proceed). Never skip updating status.
   - Add a note summarizing the outcome of each contact attempt.
   - If follow-up is needed, create a **Task** with a due date instead of
     just leaving a note.
5. Open **Opportunities** assigned to you and move each one along its
   status (`New → Pending → In Progress → Won/Lost`) as it progresses,
   keeping the **Value** and **Due Date** fields current.
6. Open **Clients** assigned to you if any policy/account details need
   updating after a conversation.
7. Before logging off, re-check the Dashboard to confirm nothing you
   touched today is still shown as due/overdue that you could have closed.

---

## 4. Lead Intake Process (Admin)

1. New lead arrives (phone/website/referral/walk-in).
2. Admin logs in → **Leads → + Add Lead**.
3. Fill in Name, Phone, Email (if known), Source, and **Assign To** the
   agent best suited (by product line, region, or current workload).
4. Agent receives the assignment (they'll see it the next time they open
   **Leads**) and must make first contact within the timeframe your
   business sets (e.g. same working day / 24 hours).
5. Admin spot-checks new leads every afternoon to confirm none are still
   at status `New` after 24 hours — if so, follow up with that agent.

---

## 5. Task Escalation

- A task overdue by **1 day**: agent should action it immediately and
  update its status.
- A task overdue by **2+ days**: Admin reassigns it or checks in directly
  with the agent to understand the blocker.
- Tasks that can no longer be completed (e.g. client no longer reachable)
  should be updated to a closed/appropriate status with a note explaining
  why — not left open indefinitely.

---

## 6. Weekly Review (Admin — e.g. every Monday morning)

1. Open **Team / Users** — confirm all 4 agent accounts are Active and
   in use; disable any account for staff who have left.
2. Open **Dashboard** — review total Overdue across Tasks and
   Opportunities; identify any pattern (one agent consistently overdue,
   one lead source performing poorly, etc.).
3. Review **Leads** with status stuck at `New` or `Contacted` for more
   than a week — reassign or close as `Lost` with a reason noted.
4. Review **Opportunities** nearing their due date — nudge the assigned
   agent, or update the date if there's a legitimate delay.
5. Back up the database file (see README.md Section 4) — weekly at minimum.

---

## 7. Account & Password Policy

- Every agent gets their **own** login — logins are never shared, even
  temporarily.
- New accounts are created by the Admin with a temporary password; the
  agent must change it on first login (**Profile → Change Password**).
- If an agent forgets their password, they ask the Admin to reset it
  (**Team / Users → Reset Password**) rather than trying to guess it.
- When an agent leaves the company, the Admin **disables** their account
  the same day (**Team / Users → Disable**) — this preserves their past
  records for history but blocks further login.
- Passwords should be at least 8 characters, not reused from other
  accounts, and not written down in a shared/public place.

---

## 8. Data Quality Rules

- One lead = one record. Before adding a new lead, check it doesn't
  already exist (search by phone number) to avoid duplicates.
- Status fields must reflect reality at all times — the Dashboard is only
  useful if statuses are kept honest and current.
- Notes should be short, factual, and dated in your head by when you wrote
  them (the system already timestamps the record's "last updated" time).
- Only an Admin deletes records, and only for genuine duplicates or
  data-entry errors — not to "clean up" a lead that simply went cold
  (mark it `Lost` instead, so the history is kept).

---

## 9. Support / Issues

- App not loading / can't log in → confirm you're using the correct URL
  and the correct email; if the password isn't working, contact the Admin
  for a reset.
- Something looks wrong with a record you don't own → do not edit it;
  flag it to the Admin, who can reassign or correct it.
- Feature requests or recurring problems → raise with the Admin, who can
  make the change using **CUSTOMIZATION.md** or arrange for a developer to.

---

*This SOP should be reviewed and updated by the Admin whenever the team's
process changes — it is a living document, not a one-time setup file.*
