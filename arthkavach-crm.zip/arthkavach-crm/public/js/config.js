// config.js
// ---------------------------------------------------------------
// EDIT THIS FILE TO CUSTOMIZE BRANDING — no other file needs to change.
// ---------------------------------------------------------------
const APP_CONFIG = {
  companyName: 'Arth Kavach Global IMF Limited',
  tagline: 'Internal CRM Portal',
  primaryColor: '#0f766e',   // teal - change to your brand color (hex)
  accentColor: '#f59e0b',    // amber - used for "overdue"/highlight badges
  logoText: 'AK',            // shown in the round logo badge (2 letters looks best)
  // To use an image logo instead of text, put a file at public/img/logo.png
  // and set useImageLogo to true.
  useImageLogo: false,
};
