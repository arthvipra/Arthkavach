// api.js - thin wrapper around fetch() for talking to the backend
const API = {
  base: '/api',
  token: localStorage.getItem('crm_token') || null,

  setToken(t) {
    this.token = t;
    if (t) localStorage.setItem('crm_token', t);
    else localStorage.removeItem('crm_token');
  },

  async request(method, path, body) {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
    };
    if (this.token) opts.headers['Authorization'] = 'Bearer ' + this.token;
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res = await fetch(this.base + path, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) {
      if (res.status === 401) { this.setToken(null); location.hash = '#/login'; }
      throw new Error((data && data.error) || 'Request failed');
    }
    return data;
  },

  get(path) { return this.request('GET', path); },
  post(path, body) { return this.request('POST', path, body); },
  patch(path, body) { return this.request('PATCH', path, body); },
  del(path) { return this.request('DELETE', path); },
};
