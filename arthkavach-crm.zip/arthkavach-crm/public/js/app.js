// app.js — the whole front-end app (single-page, hash-routed, no build step).
// To add a brand-new field to Leads/Clients/Opportunities/Tasks, see the
// MODULES config below — that's the only place you need to touch.

let CURRENT_USER = null;
let USERS_CACHE = []; // used to fill "assign to" dropdowns

const root = document.getElementById('root');

// ---------- Apply branding from config.js ----------
document.documentElement.style.setProperty('--primary', APP_CONFIG.primaryColor);
document.documentElement.style.setProperty('--accent', APP_CONFIG.accentColor);
document.title = APP_CONFIG.companyName + ' — ' + APP_CONFIG.tagline;

// ---------- Module definitions (drives list + add/edit forms) ----------
const MODULES = {
  leads: {
    title: 'Leads', api: '/leads', icon: '📇',
    columns: [
      { key: 'name', label: 'Name' },
      { key: 'phone', label: 'Phone' },
      { key: 'status', label: 'Status', status: true },
      { key: 'assigned_name', label: 'Assigned To' },
    ],
    formFields: [
      { key: 'name', label: 'Full Name', type: 'text', required: true },
      { key: 'phone', label: 'Phone', type: 'text' },
      { key: 'email', label: 'Email', type: 'email' },
      { key: 'source', label: 'Source', type: 'text', placeholder: 'e.g. Referral, Website' },
      { key: 'status', label: 'Status', type: 'select', options: ['New', 'Contacted', 'Qualified', 'Converted', 'Lost'] },
      { key: 'notes', label: 'Notes', type: 'textarea' },
      { key: 'assigned_to', label: 'Assign To', type: 'user' },
    ],
  },
  clients: {
    title: 'Clients', api: '/clients', icon: '👤',
    columns: [
      { key: 'name', label: 'Name' },
      { key: 'phone', label: 'Phone' },
      { key: 'email', label: 'Email' },
      { key: 'assigned_name', label: 'Assigned To' },
    ],
    formFields: [
      { key: 'name', label: 'Full Name', type: 'text', required: true },
      { key: 'phone', label: 'Phone', type: 'text' },
      { key: 'email', label: 'Email', type: 'email' },
      { key: 'policy_details', label: 'Policy / Account Details', type: 'textarea' },
      { key: 'assigned_to', label: 'Assign To', type: 'user' },
    ],
  },
  opportunities: {
    title: 'Opportunities', api: '/opportunities', icon: '⭐',
    columns: [
      { key: 'title', label: 'Title' },
      { key: 'value', label: 'Value' },
      { key: 'status', label: 'Status', status: true },
      { key: 'due_date', label: 'Due' },
      { key: 'assigned_name', label: 'Assigned To' },
    ],
    formFields: [
      { key: 'title', label: 'Title', type: 'text', required: true },
      { key: 'value', label: 'Value (₹)', type: 'number' },
      { key: 'status', label: 'Status', type: 'select', options: ['New', 'Pending', 'In Progress', 'Won', 'Lost'] },
      { key: 'due_date', label: 'Due Date', type: 'date' },
      { key: 'assigned_to', label: 'Assign To', type: 'user' },
    ],
  },
  tasks: {
    title: 'Tasks', api: '/tasks', icon: '✅',
    columns: [
      { key: 'title', label: 'Title' },
      { key: 'due_date', label: 'Due' },
      { key: 'status', label: 'Status', status: true },
      { key: 'assigned_name', label: 'Assigned To' },
    ],
    formFields: [
      { key: 'title', label: 'Title', type: 'text', required: true },
      { key: 'description', label: 'Description', type: 'textarea' },
      { key: 'due_date', label: 'Due Date', type: 'date' },
      { key: 'status', label: 'Status', type: 'select', options: ['Pending', 'In Progress', 'On Hold', 'Done'] },
      { key: 'assigned_to', label: 'Assign To', type: 'user' },
    ],
  },
};

// ---------- Routing ----------
window.addEventListener('hashchange', route);
window.addEventListener('DOMContentLoaded', init);

async function init() {
  if (API.token) {
    try {
      CURRENT_USER = await API.get('/auth/me');
    } catch (e) { API.setToken(null); }
  }
  route();
}

function route() {
  const hash = location.hash || '#/dashboard';
  if (!CURRENT_USER) return renderLogin();
  if (hash.startsWith('#/dashboard')) return renderDashboard();
  if (hash.startsWith('#/users')) return renderUsers();
  if (hash.startsWith('#/profile')) return renderProfile();
  for (const key of Object.keys(MODULES)) {
    if (hash.startsWith('#/' + key)) return renderModule(key);
  }
  location.hash = '#/dashboard';
}

// ---------- Login ----------
function renderLogin() {
  root.innerHTML = `
    <div class="login-wrap">
      <div class="login-card">
        <div class="login-logo">
          <div class="badge">${APP_CONFIG.logoText}</div>
          <div><b>${APP_CONFIG.companyName}</b></div>
        </div>
        <p class="tag">${APP_CONFIG.tagline}</p>
        <form id="loginForm">
          <label>Email</label>
          <input type="email" id="loginEmail" required autocomplete="username" />
          <label>Password</label>
          <input type="password" id="loginPassword" required autocomplete="current-password" />
          <div class="error-text" id="loginError"></div>
          <div style="margin-top:18px;">
            <button type="submit" style="width:100%;">Sign In</button>
          </div>
        </form>
        <div class="hint">Contact your Admin if you've forgotten your password.</div>
      </div>
    </div>`;
  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    try {
      const data = await API.post('/auth/login', { email, password });
      API.setToken(data.token);
      CURRENT_USER = data.user;
      location.hash = '#/dashboard';
      route();
    } catch (err) {
      document.getElementById('loginError').textContent = err.message;
    }
  });
}

// ---------- Shell (sidebar + topbar) ----------
function shellHtml(activeKey, title, bodyHtml) {
  const navItems = [
    { key: 'dashboard', label: 'Dashboard', icon: '🏠' },
    { key: 'leads', label: 'Leads', icon: '📇' },
    { key: 'tasks', label: 'Tasks', icon: '✅' },
    { key: 'clients', label: 'Clients', icon: '👤' },
    { key: 'opportunities', label: 'Opportunities', icon: '⭐' },
  ];
  if (CURRENT_USER.role === 'admin') navItems.push({ key: 'users', label: 'Team / Users', icon: '⚙️' });

  return `
  <div class="app-shell">
    <div class="sidebar">
      <div class="brand">
        <div class="badge">${APP_CONFIG.logoText}</div>
        <div>${APP_CONFIG.companyName}</div>
      </div>
      ${navItems.map(n => `<a class="nav-item ${activeKey === n.key ? 'active' : ''}" href="#/${n.key}">${n.icon} ${n.label}</a>`).join('')}
      <div class="sidebar-footer">Logged in as<br><b>${CURRENT_USER.name}</b> (${CURRENT_USER.role})</div>
    </div>
    <div class="main">
      <div class="topbar">
        <h2>${title}</h2>
        <div class="who">
          <a href="#/profile">Profile</a> &nbsp;|&nbsp;
          <a href="#" id="logoutLink">Log out</a>
        </div>
      </div>
      <div id="pageBody">${bodyHtml}</div>
    </div>
  </div>`;
}

function attachShellEvents() {
  const logout = document.getElementById('logoutLink');
  if (logout) logout.addEventListener('click', (e) => {
    e.preventDefault();
    API.setToken(null);
    CURRENT_USER = null;
    location.hash = '#/login';
    route();
  });
}

// ---------- Dashboard ----------
async function renderDashboard() {
  root.innerHTML = shellHtml('dashboard', 'Good day, ' + CURRENT_USER.name.split(' ')[0], '<div class="empty">Loading…</div>');
  attachShellEvents();
  let stats;
  try { stats = await API.get('/dashboard'); } catch (e) { return; }
  const body = document.getElementById('pageBody');
  body.innerHTML = `
    <div class="cards-row">
      ${statCard('Tasks', [
        ['Overdue', stats.tasks.overdue, true], ['Due Today', stats.tasks.dueToday],
        ['Unresolved', stats.tasks.unresolved], ['Pending', stats.tasks.pending],
      ], '#/tasks')}
      ${statCard('Opportunities', [
        ['Overdue', stats.opportunities.overdue, true], ['Due Today', stats.opportunities.dueToday],
        ['Pending', stats.opportunities.pending], ['New', stats.opportunities.newCount],
      ], '#/opportunities')}
      ${statCard('Leads', [
        ['Total', stats.leads.total], ['New', stats.leads.newCount],
        ['Converted', stats.leads.converted], ['', ''],
      ], '#/leads')}
    </div>
    <div class="panel">
      <div class="panel-head"><h3>Quick Actions</h3></div>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button onclick="location.hash='#/leads'">+ Add Lead</button>
        <button onclick="location.hash='#/tasks'" class="secondary">+ Add Task</button>
        <button onclick="location.hash='#/clients'" class="secondary">+ Add Client</button>
        <button onclick="location.hash='#/opportunities'" class="secondary">+ Add Opportunity</button>
      </div>
    </div>`;
}

function statCard(title, boxes, link) {
  return `<a href="${link}" style="text-decoration:none;color:inherit;">
    <div class="stat-card">
      <h4>${title}</h4>
      <div class="stat-grid">
        ${boxes.map(([lbl, num, overdue]) => lbl ? `
          <div class="stat-box ${overdue ? 'overdue' : ''}">
            <div class="num">${num}</div><div class="lbl">${lbl}</div>
          </div>` : `<div></div>`).join('')}
      </div>
    </div>
  </a>`;
}

// ---------- Generic module list view (Leads/Clients/Opportunities/Tasks) ----------
async function renderModule(key) {
  const mod = MODULES[key];
  root.innerHTML = shellHtml(key, mod.title, '<div class="empty">Loading…</div>');
  attachShellEvents();

  if (CURRENT_USER.role === 'admin' && USERS_CACHE.length === 0) {
    try { USERS_CACHE = await API.get('/auth/users'); } catch (e) {}
  }

  let rows;
  try { rows = await API.get(mod.api); } catch (e) { rows = []; }

  const body = document.getElementById('pageBody');
  body.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <h3>${mod.title} (${rows.length})</h3>
        <button id="addBtn">+ Add ${mod.title.replace(/s$/, '')}</button>
      </div>
      ${rows.length === 0 ? `<div class="empty">No ${mod.title.toLowerCase()} yet.</div>` : `
      <table>
        <thead><tr>${mod.columns.map(c => `<th>${c.label}</th>`).join('')}<th></th></tr></thead>
        <tbody>
          ${rows.map(r => `
            <tr>
              ${mod.columns.map(c => `<td>${c.status ? statusBadge(r[c.key]) : (r[c.key] ?? '')}</td>`).join('')}
              <td class="row-actions">
                <button class="secondary" onclick="openForm('${key}', ${r.id})">Edit</button>
                ${CURRENT_USER.role === 'admin' ? `<button class="danger" onclick="deleteRow('${key}', ${r.id})">Delete</button>` : ''}
              </td>
            </tr>`).join('')}
        </tbody>
      </table>`}
    </div>`;

  document.getElementById('addBtn').addEventListener('click', () => openForm(key, null));
}

function statusBadge(status) {
  if (!status) return '';
  const cls = 'st-' + status.replace(/\s+/g, '');
  return `<span class="badge-status ${cls}">${status}</span>`;
}

let editingRow = null;

async function openForm(key, id) {
  const mod = MODULES[key];
  editingRow = null;
  if (id) {
    const rows = await API.get(mod.api);
    editingRow = rows.find(r => r.id === id);
  }
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal">
      <h3>${id ? 'Edit' : 'Add'} ${mod.title.replace(/s$/, '')}</h3>
      <form id="rowForm">
        ${mod.formFields.map(f => fieldHtml(f, editingRow)).join('')}
        <div class="modal-actions">
          <button type="button" class="secondary" id="cancelBtn">Cancel</button>
          <button type="submit">${id ? 'Save Changes' : 'Create'}</button>
        </div>
      </form>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#cancelBtn').addEventListener('click', () => overlay.remove());
  overlay.querySelector('#rowForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {};
    mod.formFields.forEach(f => {
      const el = document.getElementById('f_' + f.key);
      if (!el) return;
      payload[f.key] = f.type === 'number' ? Number(el.value || 0) : el.value;
    });
    try {
      if (id) await API.patch(`${mod.api}/${id}`, payload);
      else await API.post(mod.api, payload);
      overlay.remove();
      renderModule(key);
    } catch (err) {
      alert(err.message);
    }
  });
}

function fieldHtml(f, row) {
  const val = row ? (row[f.key] ?? '') : '';
  if (f.type === 'select') {
    return `<label>${f.label}</label><select id="f_${f.key}">
      ${f.options.map(o => `<option ${val === o ? 'selected' : ''}>${o}</option>`).join('')}
    </select>`;
  }
  if (f.type === 'textarea') {
    return `<label>${f.label}</label><textarea id="f_${f.key}" rows="3">${val}</textarea>`;
  }
  if (f.type === 'user') {
    if (CURRENT_USER.role !== 'admin') return ''; // agents can't reassign; auto-assigned to self server-side
    const agents = USERS_CACHE.filter(u => u.active);
    return `<label>${f.label}</label><select id="f_${f.key}">
      <option value="">— Unassigned —</option>
      ${agents.map(u => `<option value="${u.id}" ${String(val) === String(u.id) ? 'selected' : ''}>${u.name} (${u.role})</option>`).join('')}
    </select>`;
  }
  return `<label>${f.label}${f.required ? ' *' : ''}</label>
    <input type="${f.type}" id="f_${f.key}" value="${val}" ${f.required ? 'required' : ''} placeholder="${f.placeholder || ''}" />`;
}

async function deleteRow(key, id) {
  if (!confirm('Delete this record? This cannot be undone.')) return;
  await API.del(`${MODULES[key].api}/${id}`);
  renderModule(key);
}

// ---------- Users (admin only) ----------
async function renderUsers() {
  if (CURRENT_USER.role !== 'admin') { location.hash = '#/dashboard'; return; }
  root.innerHTML = shellHtml('users', 'Team / Users', '<div class="empty">Loading…</div>');
  attachShellEvents();
  const users = await API.get('/auth/users');
  USERS_CACHE = users;
  const body = document.getElementById('pageBody');
  body.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <h3>Team Members (${users.length})</h3>
        <button id="addUserBtn">+ Add Agent / Admin</button>
      </div>
      <table>
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead>
        <tbody>
          ${users.map(u => `
            <tr>
              <td>${u.name}</td><td>${u.email}</td><td>${u.role}</td>
              <td>${u.active ? 'Active' : 'Disabled'}</td>
              <td class="row-actions">
                <button class="secondary" onclick="toggleUser(${u.id}, ${u.active ? 0 : 1})">${u.active ? 'Disable' : 'Enable'}</button>
                <button class="secondary" onclick="resetPassword(${u.id})">Reset Password</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  document.getElementById('addUserBtn').addEventListener('click', openUserForm);
}

function openUserForm() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal">
      <h3>Add Team Member</h3>
      <form id="userForm">
        <label>Full Name *</label><input id="u_name" required />
        <label>Email *</label><input id="u_email" type="email" required />
        <label>Temporary Password *</label><input id="u_password" type="text" required value="Welcome@123" />
        <label>Role</label>
        <select id="u_role"><option value="agent">Agent</option><option value="admin">Admin</option></select>
        <div class="modal-actions">
          <button type="button" class="secondary" id="cancelBtn">Cancel</button>
          <button type="submit">Create</button>
        </div>
      </form>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#cancelBtn').addEventListener('click', () => overlay.remove());
  overlay.querySelector('#userForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await API.post('/auth/users', {
        name: document.getElementById('u_name').value,
        email: document.getElementById('u_email').value,
        password: document.getElementById('u_password').value,
        role: document.getElementById('u_role').value,
      });
      overlay.remove();
      renderUsers();
    } catch (err) { alert(err.message); }
  });
}

async function toggleUser(id, active) {
  await API.patch(`/auth/users/${id}`, { active });
  renderUsers();
}
async function resetPassword(id) {
  const pw = prompt('Enter a new temporary password for this user:', 'Welcome@123');
  if (!pw) return;
  await API.patch(`/auth/users/${id}`, { password: pw });
  alert('Password reset. Share it with the team member securely.');
}

// ---------- Profile / change password ----------
function renderProfile() {
  root.innerHTML = shellHtml('profile', 'My Profile', `
    <div class="panel" style="max-width:420px;">
      <h3>${CURRENT_USER.name}</h3>
      <p style="color:var(--muted);font-size:14px;">${CURRENT_USER.email} — ${CURRENT_USER.role}</p>
      <form id="pwForm">
        <label>Current Password</label><input type="password" id="curPw" required />
        <label>New Password</label><input type="password" id="newPw" required minlength="6" />
        <div class="error-text" id="pwError"></div>
        <div style="margin-top:16px;"><button type="submit">Change Password</button></div>
      </form>
    </div>`);
  attachShellEvents();
  document.getElementById('pwForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await API.post('/auth/change-password', {
        currentPassword: document.getElementById('curPw').value,
        newPassword: document.getElementById('newPw').value,
      });
      alert('Password updated.');
      renderProfile();
    } catch (err) {
      document.getElementById('pwError').textContent = err.message;
    }
  });
}
