# Customization Guide

Everything below can be done without knowing how to code — just edit the
named file, save it, and restart the server (`npm start`) or redeploy.

---

## 1. Change company name, tagline, colors, logo

Open **`public/js/config.js`**:

```js
const APP_CONFIG = {
  companyName: 'Arth Kavach Global IMF Limited',
  tagline: 'Internal CRM Portal',
  primaryColor: '#0f766e',   // main brand color (sidebar, buttons)
  accentColor: '#f59e0b',    // used for "overdue" highlights
  logoText: 'AK',             // 2 letters shown in the round logo badge
  useImageLogo: false,
};
```

- Change `companyName` and `tagline` to whatever you want displayed on the
  login screen and browser tab.
- Change `primaryColor`/`accentColor` to your brand's hex codes (ask your
  designer, or use any color-picker website to get a hex code like `#123abc`).
- Change `logoText` to your initials (2 letters reads best in the round badge).
- To use an actual logo **image** instead of text initials:
  1. Save your logo as `public/img/logo.png`
  2. Set `useImageLogo: true` in the file above
  3. In `public/index.html` and `public/js/app.js`, replace the
     `<div class="badge">${APP_CONFIG.logoText}</div>` lines with
     `<img src="img/logo.png" style="width:34px;height:34px;border-radius:8px;">`

---

## 2. Add a new field to Leads, Clients, Opportunities or Tasks

Example: adding a "PAN Number" field to Leads.

**Step 1 — Database** (`server/db/database.js`): add a column to the
`CREATE TABLE leads` block, e.g. `pan_number TEXT,`. If the app is already
running with data in it, instead run this once against the database:
```bash
sqlite3 server/db/crm.db "ALTER TABLE leads ADD COLUMN pan_number TEXT;"
```

**Step 2 — Backend** (`server/routes/leads.js`): add `'pan_number'` to the
`fields` array.

**Step 3 — Frontend** (`public/js/app.js`): find `MODULES.leads` near the
top of the file and add a line to `columns` (to show it in the table) and/or
`formFields` (to let people enter it), e.g.:
```js
{ key: 'pan_number', label: 'PAN Number', type: 'text' },
```

Restart the server. The new field now appears in the Leads table and form.
The same 3 steps work for Clients, Opportunities and Tasks — just edit the
matching table name / route file / `MODULES` entry.

---

## 3. Add a 5th (or 6th) agent, or a 2nd admin

You don't need to touch any code for this — once logged in as Admin, go to
**Team / Users → + Add Agent / Admin**, fill in their name, email, a
temporary password, and role. They can log in immediately and should change
their password from **Profile** on first login.

(Alternatively, for the *initial* batch of users, edit the `USERS` list in
`server/db/seed.js` before running `npm run seed` for the first time.)

---

## 4. Change what Admin vs Agent can see or do

Open **`server/routes/makeCrud.js`** — this one file controls the
permission rules shared by Leads/Clients/Opportunities/Tasks:
- The `LIST` section decides what an agent is allowed to see (currently:
  only records where `assigned_to` = their own user id).
- The `UPDATE` section decides who can edit what.
- The `DELETE` section currently restricts deleting to Admins only.

Each is a short, commented block — change the condition to loosen or
tighten access (e.g. let agents see each other's leads by removing the
`WHERE assigned_to = ?` filter for agents too).

---

## 5. Change the status options (e.g. add "Negotiation" to Opportunities)

Two places need the same list updated:
1. `server/routes/opportunities.js` — the `allowedStatus` array
2. `public/js/app.js` — inside `MODULES.opportunities.formFields`, the
   `status` field's `options` array

Also add a matching color in `public/css/style.css` if you want a distinct
badge color (copy one of the existing `.st-XXX` rules and rename it to
match your new status with spaces removed, e.g. `Negotiation` → `.st-Negotiation`).

---

## 6. Rename "Opportunities" to something else (e.g. "Policies")

In `public/js/app.js`, change `title: 'Opportunities'` to `title: 'Policies'`
inside the `MODULES.opportunities` object. The sidebar link, page heading,
and buttons all read from that one value.

---

## 7. Change the dashboard counters

`server/routes/dashboard.js` defines what "Overdue", "Due Today", "Pending"
etc. count. Each is a small SQL condition you can adjust, e.g. change how
many days ahead counts as "Due Soon", or add a new counter by copying an
existing `count(...)` line and adding it to the returned object — then add
a matching box for it in the dashboard rendering in `public/js/app.js`
(`renderDashboard` function, inside `statCard`).
