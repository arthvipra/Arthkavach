// seed.js
// Creates the first 5 logins: 1 admin + 4 agents.
// Run once with:  npm run seed
// Safe to re-run — it skips any user whose email already exists.
//
// >>> EDIT THE LIST BELOW to set real names/emails for your team. <<<
// Change the passwords immediately after first login (see SOP.md).

const bcrypt = require('bcryptjs');
const db = require('./database');

const USERS = [
  { name: 'Admin',   email: 'admin@arthkavach.com',  password: 'Admin@123',  role: 'admin' },
  { name: 'Agent 1', email: 'agent1@arthkavach.com',  password: 'Agent1@123', role: 'agent' },
  { name: 'Agent 2', email: 'agent2@arthkavach.com',  password: 'Agent2@123', role: 'agent' },
  { name: 'Agent 3', email: 'agent3@arthkavach.com',  password: 'Agent3@123', role: 'agent' },
  { name: 'Agent 4', email: 'agent4@arthkavach.com',  password: 'Agent4@123', role: 'agent' },
];

const insert = db.prepare(
  `INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)`
);
const exists = db.prepare(`SELECT id FROM users WHERE email = ?`);

for (const u of USERS) {
  if (exists.get(u.email)) {
    console.log(`Skipped (already exists): ${u.email}`);
    continue;
  }
  const hash = bcrypt.hashSync(u.password, 10);
  insert.run(u.name, u.email, hash, u.role);
  console.log(`Created ${u.role}: ${u.email} / ${u.password}`);
}

console.log('\nSeed complete. Log in at the app URL with the emails/passwords above,');
console.log('then change every password immediately from the Profile menu.');
