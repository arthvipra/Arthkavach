const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'change_this_to_a_long_random_secret_string';

// Verifies the login token sent by the browser and attaches the user
// (id, role) to req.user. Blocks the request if the token is missing/bad.
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Not logged in' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session expired, please log in again' });
  }
}

// Use after requireAuth to restrict a route to admins only.
function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admins only' });
  }
  next();
}

module.exports = { requireAuth, requireAdmin, SECRET };
