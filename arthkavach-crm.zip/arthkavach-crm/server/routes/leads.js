const makeCrud = require('./makeCrud');
module.exports = makeCrud({
  table: 'leads',
  fields: ['name', 'phone', 'email', 'source', 'status', 'notes', 'assigned_to'],
  allowedStatus: ['New', 'Contacted', 'Qualified', 'Converted', 'Lost'],
});
