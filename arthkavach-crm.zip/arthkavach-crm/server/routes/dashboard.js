const express = require('express');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();

// GET /api/dashboard -> the Overdue/Due Today/Pending style counters
// shown on the home screen, scoped to the logged-in user (or everyone
// for admin).
router.get('/', requireAuth, (req, res) => {
  const scope = req.user.role === 'admin' ? '' : 'AND assigned_to = ?';
  const args = req.user.role === 'admin' ? [] : [req.user.id];

  const count = (table, extraWhere = '1=1', extraArgs = []) =>
    db.prepare(`SELECT COUNT(*) AS c FROM ${table} WHERE ${extraWhere} ${scope}`).get(...extraArgs, ...args).c;

  const tasks = {
    overdue: count('tasks', "status != 'Done' AND due_date < date('now')"),
    dueToday: count('tasks', "status != 'Done' AND due_date = date('now')"),
    unresolved: count('tasks', "status != 'Done'"),
    pending: count('tasks', "status = 'Pending'"),
    inProgress: count('tasks', "status = 'In Progress'"),
    onHold: count('tasks', "status = 'On Hold'"),
  };

  const opportunities = {
    overdue: count('opportunities', "status NOT IN ('Won','Lost') AND due_date < date('now')"),
    dueToday: count('opportunities', "status NOT IN ('Won','Lost') AND due_date = date('now')"),
    pending: count('opportunities', "status = 'Pending'"),
    newCount: count('opportunities', "status = 'New'"),
  };

  const leads = {
    total: count('leads', '1=1'),
    newCount: count('leads', "status = 'New'"),
    converted: count('leads', "status = 'Converted'"),
  };

  res.json({ tasks, opportunities, leads });
});

module.exports = router;
