const express = require('express');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

// Builds a small REST API (list/create/update/delete) for one table.
// Agents only ever see/edit rows assigned to them; admins see everything
// and can assign rows to any agent. This one function is reused for
// leads, clients, opportunities and tasks so each file below stays tiny.
function makeCrud({ table, fields, allowedStatus }) {
  const router = express.Router();

  // LIST
  router.get('/', requireAuth, (req, res) => {
    let rows;
    if (req.user.role === 'admin') {
      rows = db.prepare(`SELECT ${table}.*, u.name AS assigned_name FROM ${table}
                          LEFT JOIN users u ON u.id = ${table}.assigned_to
                          ORDER BY ${table}.id DESC`).all();
    } else {
      rows = db.prepare(`SELECT ${table}.*, u.name AS assigned_name FROM ${table}
                          LEFT JOIN users u ON u.id = ${table}.assigned_to
                          WHERE ${table}.assigned_to = ?
                          ORDER BY ${table}.id DESC`).all(req.user.id);
    }
    res.json(rows);
  });

  // CREATE
  router.post('/', requireAuth, (req, res) => {
    const cols = [];
    const placeholders = [];
    const values = [];
    for (const f of fields) {
      if (req.body[f] !== undefined) {
        cols.push(f);
        placeholders.push('?');
        values.push(req.body[f]);
      }
    }
    cols.push('created_by'); placeholders.push('?'); values.push(req.user.id);
    // Agents creating a record auto-assign it to themselves unless admin sets assigned_to
    if (req.user.role === 'agent' && !cols.includes('assigned_to')) {
      cols.push('assigned_to'); placeholders.push('?'); values.push(req.user.id);
    }
    const sql = `INSERT INTO ${table} (${cols.join(',')}) VALUES (${placeholders.join(',')})`;
    const info = db.prepare(sql).run(...values);
    res.json({ id: info.lastInsertRowid });
  });

  // UPDATE
  router.patch('/:id', requireAuth, (req, res) => {
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
    if (!row) return res.status(404).json({ error: 'Not found' });
    if (req.user.role !== 'admin' && row.assigned_to !== req.user.id) {
      return res.status(403).json({ error: 'You can only edit items assigned to you' });
    }
    if (allowedStatus && req.body.status && !allowedStatus.includes(req.body.status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    // Only admin can reassign a record to a different agent
    if (req.body.assigned_to !== undefined && req.user.role !== 'admin') {
      delete req.body.assigned_to;
    }
    const sets = [];
    const values = [];
    for (const f of [...fields, 'assigned_to']) {
      if (req.body[f] !== undefined) {
        sets.push(`${f} = ?`);
        values.push(req.body[f]);
      }
    }
    if (sets.length === 0) return res.json({ success: true });
    sets.push("updated_at = datetime('now')");
    values.push(req.params.id);
    db.prepare(`UPDATE ${table} SET ${sets.join(', ')} WHERE id = ?`).run(...values);
    res.json({ success: true });
  });

  // DELETE (admin only, to avoid agents losing history accidentally)
  router.delete('/:id', requireAuth, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only' });
    db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(req.params.id);
    res.json({ success: true });
  });

  return router;
}

module.exports = makeCrud;
