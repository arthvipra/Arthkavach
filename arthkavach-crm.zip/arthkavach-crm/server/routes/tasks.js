const makeCrud = require('./makeCrud');
module.exports = makeCrud({
  table: 'tasks',
  fields: ['title', 'description', 'due_date', 'status', 'related_lead_id', 'related_client_id', 'assigned_to'],
  allowedStatus: ['Pending', 'In Progress', 'On Hold', 'Done'],
});
