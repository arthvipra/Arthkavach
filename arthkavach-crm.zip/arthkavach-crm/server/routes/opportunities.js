const makeCrud = require('./makeCrud');
module.exports = makeCrud({
  table: 'opportunities',
  fields: ['title', 'client_id', 'value', 'status', 'due_date', 'assigned_to'],
  allowedStatus: ['New', 'Pending', 'In Progress', 'Won', 'Lost'],
});
