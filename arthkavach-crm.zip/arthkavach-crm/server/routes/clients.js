const makeCrud = require('./makeCrud');
module.exports = makeCrud({
  table: 'clients',
  fields: ['name', 'phone', 'email', 'policy_details', 'assigned_to'],
});
