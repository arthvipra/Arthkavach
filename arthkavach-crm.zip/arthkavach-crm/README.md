# Arth Kavach Global IMF Limited — Internal CRM

A lightweight CRM web app for **1 Admin + 4 Agents** to manage Leads, Clients,
Opportunities and Tasks — similar in spirit to the dashboard you shared
(Overdue/Due Today/Pending counters, role-based views).

- **Backend:** Node.js + Express + SQLite (one file database, no external DB server needed)
- **Frontend:** Plain HTML/CSS/JS (no build step, no framework install needed)
- **Auth:** Email + password login, JSON Web Tokens, roles = `admin` / `agent`

---

## 1. What each role can do

| Action | Admin | Agent |
|---|---|---|
| View all Leads/Clients/Tasks/Opportunities | ✅ all records | ❌ only records assigned to them |
| Create a record | ✅ can assign to any agent | ✅ auto-assigned to themselves |
| Edit a record | ✅ any record | ✅ only their own |
| Reassign a record to another agent | ✅ | ❌ |
| Delete a record | ✅ | ❌ |
| Add / disable team members | ✅ | ❌ |
| Reset a teammate's password | ✅ | ❌ |
| Change their own password | ✅ | ✅ |

---

## 2. Run it on your own computer (for testing)

Requirements: [Node.js](https://nodejs.org) version 18 or later.

```bash
cd server
npm install
cp .env.example .env      # then open .env and set a real JWT_SECRET
npm run seed               # creates the 1 admin + 4 agent logins (see below)
npm start                  # starts the server
```

Open **http://localhost:4000** in your browser and log in.

### Default logins created by `npm run seed`

| Role | Email | Password |
|---|---|---|
| Admin | admin@arthkavach.com | Admin@123 |
| Agent 1 | agent1@arthkavach.com | Agent1@123 |
| Agent 2 | agent2@arthkavach.com | Agent2@123 |
| Agent 3 | agent3@arthkavach.com | Agent3@123 |
| Agent 4 | agent4@arthkavach.com | Agent4@123 |

**Change every one of these passwords on first login** (Profile → Change Password,
or ask the Admin to set custom ones — see `server/db/seed.js` to edit names/emails
before you seed, or add real employees from the in-app **Team / Users** screen
once you're logged in as Admin).

---

## 3. Put it online so your 4 agents can access it from anywhere

You don't need your own server room for this — any of the following work.
All of them are free or a few hundred rupees a month for this size of app.

### Option A — Render.com (easiest, recommended)
1. Create a free account at render.com and connect it to a GitHub repo
   containing this project (push this folder to a new GitHub repo first).
2. Click **New → Web Service**, point it at the repo, set:
   - Root directory: `server`
   - Build command: `npm install`
   - Start command: `npm start`
3. Under **Environment**, add `JWT_SECRET` (any long random string) and `PORT=4000`.
4. Deploy. Render gives you a URL like `https://arthkavach-crm.onrender.com`.
5. SSH/Shell into the Render instance (or run `npm run seed` locally against
   the same repo once, then deploy the resulting `server/db/crm.db` file) to
   create the 5 logins.
6. Share the URL with your admin and 4 agents.

### Option B — Railway.app
Same idea as Render: new project → deploy from GitHub → set root to `server`
→ set `JWT_SECRET` → deploy.

### Option C — Your own VPS (e.g. a ₹300/month DigitalOcean/AWS Lightsail box)
```bash
# on the server, after installing Node.js:
git clone <your-repo-url> arthkavach-crm
cd arthkavach-crm/server
npm install
cp .env.example .env   # edit JWT_SECRET
npm run seed
npm install -g pm2
pm2 start server.js --name arthkavach-crm   # keeps it running after reboot/SSH close
pm2 save
```
Then put a domain/subdomain (e.g. `crm.arthkavach.com`) in front of it with
Nginx + a free SSL certificate from Let's Encrypt/Certbot, so the login
page is served over `https://`.

**Important:** wherever you host it, always use HTTPS in production — a
login form should never be sent over plain `http://` on the public internet.

---

## 4. Backing up your data

All the data lives in one file: `server/db/crm.db`. To back it up, just
copy that file somewhere safe (e.g. download it weekly, or set up an
automatic copy to Google Drive/S3). To restore, put the backed-up file
back at that same path and restart the server.

---

## 5. Project structure

```
arthkavach-crm/
├── server/                 # Node.js/Express backend + SQLite database
│   ├── server.js           # entry point
│   ├── db/
│   │   ├── database.js     # table definitions
│   │   ├── seed.js         # creates admin + 4 agents (EDIT NAMES/EMAILS HERE)
│   │   └── crm.db          # the actual database file (created after seeding)
│   ├── middleware/auth.js  # login/token checking
│   └── routes/              # API endpoints (auth, leads, clients, opportunities, tasks, dashboard)
├── public/                  # the frontend (what agents see in the browser)
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── config.js        # <-- EDIT THIS for branding (see CUSTOMIZATION.md)
│       ├── api.js
│       └── app.js           # <-- EDIT MODULES{} here to add/change fields
├── CUSTOMIZATION.md          # step-by-step guide to reskin/extend the app
└── SOP.md                    # standard operating procedure for your team
```

See **CUSTOMIZATION.md** for how to change the logo/colors/company name and
add new fields, and **SOP.md** for the day-to-day process your Admin and
Agents should follow once the CRM is live.
